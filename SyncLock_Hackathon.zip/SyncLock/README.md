# SyncLock — Concurrent File Access Management System

A hackathon-ready web application that demonstrates safe concurrent access to shared files.

## Features

- Multiple concurrent readers using shared locks
- Exclusive writer locking using OS-level file locks
- Optimistic concurrency/version checking
- Atomic file replacement to reduce partial-write risk
- SQLite metadata and activity logging
- Conflict detection
- Live dashboard with statistics
- File creation, editing, reading and deletion
- Multi-process concurrency simulator

## Requirements

- Python 3.9+
- Windows, Linux, or macOS

## Setup

```bash
python -m venv .venv
```

Activate the environment and install:

```bash
pip install -r requirements.txt
```

## Start the web application

```bash
uvicorn app:app --reload
```

Open:

http://127.0.0.1:8000

## Run the concurrency demonstration

In another terminal:

```bash
python simulator.py
```

The simulator starts five independent processes that attempt to update the same file. The exclusive lock forces the writes to happen safely one at a time.

## Architecture

Browser
  |
  v
FastAPI API
  |
  +--> File Lock Manager --> Shared Files
  |
  +--> SQLite --> Versions + Activity Logs

## Core concurrency mechanisms

### Shared read lock

Multiple readers can access a file concurrently.

### Exclusive write lock

Only one writer can update a file at a time.

### Version checking

A write request includes the version that the client originally read. If another update has already changed the version, the second write is rejected as a conflict.

### Atomic replacement

New content is written to a temporary file and then moved into place with an atomic replacement operation.

## Suggested hackathon demo

1. Open the dashboard.
2. Select `shared.txt`.
3. Edit and save it.
4. Open another browser tab and load the same file.
5. Save from one tab first.
6. Try saving stale content from the second tab.
7. Show the version conflict in the Activity Monitor.
8. Run `python simulator.py` to demonstrate five independent processes contending for the same write lock.

## Important note

This project is a prototype for demonstrating concurrency concepts. For a production distributed file service, use a dedicated distributed lock/transaction architecture and stronger authentication/authorization.
