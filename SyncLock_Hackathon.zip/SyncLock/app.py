import os
import asyncio
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel

from database import (
    init_database,
    register_file,
    get_file,
    update_version,
    delete_file_record,
    log_activity,
    get_recent_logs,
    get_statistics,
)
from lock_manager import FileLockManager, STORAGE_DIR


app = FastAPI(
    title="SyncLock",
    description="Concurrent File Access Management System",
    version="1.0.0",
)


class WriteRequest(BaseModel):
    content: str
    expected_version: int


class CreateFileRequest(BaseModel):
    filename: str
    content: str = ""


def validate_filename(filename: str):
    if not filename:
        raise HTTPException(
            status_code=400,
            detail="Filename cannot be empty",
        )

    if "/" in filename or "\\" in filename:
        raise HTTPException(
            status_code=400,
            detail="Invalid filename",
        )

    if filename.startswith(".") or filename in {".", ".."}:
        raise HTTPException(
            status_code=400,
            detail="Invalid filename",
        )


@app.on_event("startup")
def startup():
    init_database()

    default_file = STORAGE_DIR / "shared.txt"

    if not default_file.exists():
        default_file.write_text(
            "Welcome to SyncLock!\n"
            "This is a shared file.\n",
            encoding="utf-8",
        )

    register_file("shared.txt")


@app.get("/")
async def home():
    return FileResponse("templates/index.html")


@app.get("/api/files")
async def list_files():
    files = []

    for path in STORAGE_DIR.iterdir():
        if path.is_file() and not path.name.endswith(".tmp"):
            if path.name.startswith("."):
                continue

            metadata = get_file(path.name)

            if metadata:
                files.append(
                    {
                        "filename": path.name,
                        "version": metadata["version"],
                        "updated_at": metadata["updated_at"],
                        "size": path.stat().st_size,
                    }
                )

    files.sort(key=lambda item: item["filename"].lower())
    return files


@app.post("/api/files")
async def create_file(request: CreateFileRequest):
    validate_filename(request.filename)

    file_path = STORAGE_DIR / request.filename

    if file_path.exists():
        raise HTTPException(
            status_code=409,
            detail="File already exists",
        )

    manager = FileLockManager(request.filename)
    pid = str(os.getpid())
    acquired = False

    try:
        acquired = await asyncio.to_thread(manager.acquire_exclusive)

        if not acquired:
            raise HTTPException(
                status_code=423,
                detail="Could not acquire exclusive lock",
            )

        manager.create(request.content)
        register_file(request.filename)

        log_activity(
            request.filename,
            pid,
            "CREATE",
            "SUCCESS",
            "File created",
        )

        return {
            "message": "File created",
            "filename": request.filename,
        }

    finally:
        if acquired:
            manager.release()


@app.get("/api/files/{filename}")
async def read_file(filename: str):
    validate_filename(filename)

    metadata = get_file(filename)

    if not metadata:
        raise HTTPException(
            status_code=404,
            detail="File not found",
        )

    manager = FileLockManager(filename)
    pid = str(os.getpid())
    acquired = False

    try:
        acquired = await asyncio.to_thread(manager.acquire_shared)

        if not acquired:
            log_activity(
                filename,
                pid,
                "READ",
                "BLOCKED",
                "Could not acquire shared read lock",
            )
            raise HTTPException(
                status_code=423,
                detail="Could not acquire read lock",
            )

        content = await asyncio.to_thread(manager.read)

        log_activity(
            filename,
            pid,
            "READ",
            "SUCCESS",
            "Shared read lock acquired",
        )

        return {
            "filename": filename,
            "content": content,
            "version": metadata["version"],
        }

    finally:
        if acquired:
            manager.release()


@app.post("/api/files/{filename}/write")
async def write_file(filename: str, request: WriteRequest):
    validate_filename(filename)

    metadata = get_file(filename)

    if not metadata:
        raise HTTPException(
            status_code=404,
            detail="File not found",
        )

    manager = FileLockManager(filename)
    pid = str(os.getpid())
    acquired = False

    try:
        acquired = await asyncio.to_thread(manager.acquire_exclusive)

        if not acquired:
            log_activity(
                filename,
                pid,
                "WRITE",
                "BLOCKED",
                "Unable to acquire exclusive lock",
            )
            raise HTTPException(
                status_code=423,
                detail="File is currently locked",
            )

        # Re-read metadata after acquiring the lock.
        metadata = get_file(filename)
        current_version = metadata["version"]

        if request.expected_version != current_version:
            log_activity(
                filename,
                pid,
                "WRITE",
                "CONFLICT",
                (
                    f"Version conflict. Expected "
                    f"{request.expected_version}, current version "
                    f"{current_version}"
                ),
            )

            raise HTTPException(
                status_code=409,
                detail={
                    "message": "Version conflict",
                    "expected_version": request.expected_version,
                    "current_version": current_version,
                },
            )

        await asyncio.to_thread(
            manager.write,
            request.content,
        )

        new_version = update_version(filename)

        log_activity(
            filename,
            pid,
            "WRITE",
            "SUCCESS",
            f"File updated to version {new_version}",
        )

        return {
            "message": "File updated successfully",
            "filename": filename,
            "version": new_version,
        }

    finally:
        if acquired:
            manager.release()


@app.delete("/api/files/{filename}")
async def delete_file(filename: str):
    validate_filename(filename)

    metadata = get_file(filename)

    if not metadata:
        raise HTTPException(
            status_code=404,
            detail="File not found",
        )

    manager = FileLockManager(filename)
    pid = str(os.getpid())
    acquired = await asyncio.to_thread(manager.acquire_exclusive)

    if not acquired:
        log_activity(
            filename,
            pid,
            "DELETE",
            "BLOCKED",
            "Could not acquire exclusive lock",
        )
        raise HTTPException(
            status_code=423,
            detail="File is currently locked",
        )

    try:
        await asyncio.to_thread(manager.delete)
        delete_file_record(filename)

        log_activity(
            filename,
            pid,
            "DELETE",
            "SUCCESS",
            "File deleted",
        )

        return {"message": "File deleted"}

    finally:
        manager.release()


@app.get("/api/logs")
async def logs():
    return get_recent_logs(100)


@app.get("/api/statistics")
async def statistics():
    return get_statistics()


@app.get("/api/health")
async def health():
    return {
        "status": "running",
        "service": "SyncLock",
    }
