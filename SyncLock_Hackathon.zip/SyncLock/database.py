import sqlite3
from datetime import datetime
from pathlib import Path


DB_PATH = Path("synclock.db")


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_database():
    conn = get_connection()

    conn.execute(
        '''
        CREATE TABLE IF NOT EXISTS files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT UNIQUE NOT NULL,
            version INTEGER DEFAULT 1,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        '''
    )

    conn.execute(
        '''
        CREATE TABLE IF NOT EXISTS activity_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT,
            process_id TEXT,
            operation TEXT,
            status TEXT,
            message TEXT,
            timestamp TEXT NOT NULL
        )
        '''
    )

    conn.commit()
    conn.close()


def register_file(filename):
    now = datetime.now().isoformat(timespec="seconds")

    conn = get_connection()

    conn.execute(
        '''
        INSERT OR IGNORE INTO files
        (filename, version, created_at, updated_at)
        VALUES (?, 1, ?, ?)
        ''',
        (filename, now, now),
    )

    conn.commit()
    conn.close()


def get_file(filename):
    conn = get_connection()

    row = conn.execute(
        '''
        SELECT *
        FROM files
        WHERE filename = ?
        ''',
        (filename,),
    ).fetchone()

    conn.close()

    return dict(row) if row else None


def update_version(filename):
    now = datetime.now().isoformat(timespec="seconds")

    conn = get_connection()

    conn.execute(
        '''
        UPDATE files
        SET version = version + 1,
            updated_at = ?
        WHERE filename = ?
        ''',
        (now, filename),
    )

    conn.commit()

    row = conn.execute(
        '''
        SELECT version
        FROM files
        WHERE filename = ?
        ''',
        (filename,),
    ).fetchone()

    conn.close()

    return row["version"]


def delete_file_record(filename):
    conn = get_connection()

    conn.execute(
        '''
        DELETE FROM files
        WHERE filename = ?
        ''',
        (filename,),
    )

    conn.commit()
    conn.close()


def log_activity(filename, process_id, operation, status, message):
    now = datetime.now().isoformat(timespec="seconds")

    conn = get_connection()

    conn.execute(
        '''
        INSERT INTO activity_logs
        (filename, process_id, operation, status, message, timestamp)
        VALUES (?, ?, ?, ?, ?, ?)
        ''',
        (
            filename,
            process_id,
            operation,
            status,
            message,
            now,
        ),
    )

    conn.commit()
    conn.close()


def get_recent_logs(limit=50):
    conn = get_connection()

    rows = conn.execute(
        '''
        SELECT *
        FROM activity_logs
        ORDER BY id DESC
        LIMIT ?
        ''',
        (limit,),
    ).fetchall()

    conn.close()

    return [dict(row) for row in rows]


def get_statistics():
    conn = get_connection()

    total_files = conn.execute(
        "SELECT COUNT(*) AS count FROM files"
    ).fetchone()["count"]

    total_operations = conn.execute(
        "SELECT COUNT(*) AS count FROM activity_logs"
    ).fetchone()["count"]

    conflicts = conn.execute(
        '''
        SELECT COUNT(*) AS count
        FROM activity_logs
        WHERE status = 'CONFLICT'
        '''
    ).fetchone()["count"]

    successful_writes = conn.execute(
        '''
        SELECT COUNT(*) AS count
        FROM activity_logs
        WHERE operation = 'WRITE'
        AND status = 'SUCCESS'
        '''
    ).fetchone()["count"]

    conn.close()

    return {
        "total_files": total_files,
        "total_operations": total_operations,
        "conflicts_blocked": conflicts,
        "successful_writes": successful_writes,
    }
