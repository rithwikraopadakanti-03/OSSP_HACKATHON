import os
from pathlib import Path

import portalocker


STORAGE_DIR = Path("storage")
LOCK_DIR = STORAGE_DIR / ".locks"

STORAGE_DIR.mkdir(exist_ok=True)
LOCK_DIR.mkdir(exist_ok=True)


class FileLockManager:
    def __init__(self, filename):
        self.filename = filename
        self.file_path = STORAGE_DIR / filename
        self.lock_path = LOCK_DIR / f"{filename}.lock"
        self.lock_file = None

    def acquire_shared(self):
        self.lock_file = open(self.lock_path, "a+", encoding="utf-8")

        try:
            portalocker.lock(
                self.lock_file,
                portalocker.LOCK_SH,
            )
            return True
        except Exception:
            self.lock_file.close()
            self.lock_file = None
            return False

    def acquire_exclusive(self):
        self.lock_file = open(self.lock_path, "a+", encoding="utf-8")

        try:
            portalocker.lock(
                self.lock_file,
                portalocker.LOCK_EX,
            )
            return True
        except Exception:
            self.lock_file.close()
            self.lock_file = None
            return False

    def release(self):
        if self.lock_file:
            try:
                portalocker.unlock(self.lock_file)
            finally:
                self.lock_file.close()
                self.lock_file = None

    def read(self):
        if not self.file_path.exists():
            return None

        with open(
            self.file_path,
            "r",
            encoding="utf-8",
        ) as file:
            return file.read()

    def write(self, content):
        temp_path = self.file_path.with_suffix(
            self.file_path.suffix + ".tmp"
        )

        with open(
            temp_path,
            "w",
            encoding="utf-8",
        ) as file:
            file.write(content)
            file.flush()
            os.fsync(file.fileno())

        os.replace(
            temp_path,
            self.file_path,
        )

    def create(self, content=""):
        self.file_path.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        with open(
            self.file_path,
            "w",
            encoding="utf-8",
        ) as file:
            file.write(content)

    def delete(self):
        if self.file_path.exists():
            self.file_path.unlink()
