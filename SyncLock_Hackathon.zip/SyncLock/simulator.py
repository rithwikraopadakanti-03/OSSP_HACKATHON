import multiprocessing
import os
import time
from pathlib import Path

import portalocker


STORAGE_DIR = Path("storage")
LOCK_DIR = STORAGE_DIR / ".locks"

FILE_NAME = "simulation.txt"
FILE_PATH = STORAGE_DIR / FILE_NAME
LOCK_PATH = LOCK_DIR / f"{FILE_NAME}.lock"


def worker(worker_id):
    pid = os.getpid()

    print(
        f"[Process {worker_id} | PID {pid}] "
        "Requesting WRITE lock...",
        flush=True,
    )

    with open(
        LOCK_PATH,
        "a+",
        encoding="utf-8",
    ) as lock_file:

        start = time.time()

        portalocker.lock(
            lock_file,
            portalocker.LOCK_EX,
        )

        wait_time = time.time() - start

        print(
            f"[Process {worker_id} | PID {pid}] "
            f"LOCK ACQUIRED after {wait_time:.2f}s",
            flush=True,
        )

        try:
            existing = ""

            if FILE_PATH.exists():
                existing = FILE_PATH.read_text(
                    encoding="utf-8"
                )

            # Simulate work while holding the write lock.
            time.sleep(2)

            new_data = (
                existing
                + f"Process {worker_id} "
                  f"(PID {pid}) updated the file.\n"
            )

            temp_file = FILE_PATH.with_suffix(".tmp")

            temp_file.write_text(
                new_data,
                encoding="utf-8",
            )

            temp_file.replace(FILE_PATH)

            print(
                f"[Process {worker_id} | PID {pid}] "
                "FILE UPDATED",
                flush=True,
            )

        finally:
            portalocker.unlock(lock_file)

            print(
                f"[Process {worker_id} | PID {pid}] "
                "LOCK RELEASED",
                flush=True,
            )


def main():
    STORAGE_DIR.mkdir(exist_ok=True)
    LOCK_DIR.mkdir(exist_ok=True)

    FILE_PATH.write_text(
        "=== Concurrent Access Simulation ===\n",
        encoding="utf-8",
    )

    print("\nStarting concurrent processes...\n")

    processes = []

    for i in range(1, 6):
        process = multiprocessing.Process(
            target=worker,
            args=(i,),
        )

        processes.append(process)
        process.start()

    for process in processes:
        process.join()

    print("\n=== FINAL FILE CONTENT ===\n")

    print(
        FILE_PATH.read_text(
            encoding="utf-8"
        )
    )


if __name__ == "__main__":
    main()
