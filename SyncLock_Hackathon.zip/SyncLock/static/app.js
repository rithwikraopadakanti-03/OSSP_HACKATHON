let currentFilename = null;
let currentVersion = null;

async function api(url, options = {}) {
    const response = await fetch(url, {
        ...options,
        headers: {
            "Content-Type": "application/json",
            ...(options.headers || {}),
        },
    });

    const data = await response.json();

    if (!response.ok) {
        throw new Error(JSON.stringify(data.detail));
    }

    return data;
}

async function loadFiles() {
    try {
        const files = await api("/api/files");
        const container = document.getElementById("fileList");

        if (files.length === 0) {
            container.innerHTML = "<p>No shared files.</p>";
            return;
        }

        container.innerHTML = files.map(file => `
            <div class="file-item"
                 onclick="selectFile('${escapeHtml(file.filename)}')">

                <div>
                    <div class="file-name">
                        📄 ${escapeHtml(file.filename)}
                    </div>

                    <div class="file-meta">
                        Version ${file.version}
                        • ${file.size} bytes
                        • Updated ${escapeHtml(file.updated_at)}
                    </div>
                </div>

                <button
                    class="secondary"
                    onclick="event.stopPropagation();
                             deleteFile('${escapeHtml(file.filename)}')">
                    Delete
                </button>
            </div>
        `).join("");
    } catch (error) {
        console.error(error);
    }
}

async function selectFile(filename) {
    currentFilename = filename;
    await readCurrentFile();
}

async function readCurrentFile() {
    if (!currentFilename) {
        alert("Please select a file first.");
        return;
    }

    try {
        const data = await api(
            `/api/files/${encodeURIComponent(currentFilename)}`
        );

        currentVersion = data.version;

        document.getElementById("currentFile").textContent =
            data.filename;

        document.getElementById("version").textContent =
            `Version ${data.version}`;

        const editor = document.getElementById("editor");
        editor.disabled = false;
        editor.value = data.content;
    } catch (error) {
        alert("Unable to read file:\n" + error.message);
    }
}

async function saveFile() {
    if (!currentFilename) {
        alert("Select a file first.");
        return;
    }

    const content = document.getElementById("editor").value;

    try {
        const data = await api(
            `/api/files/${encodeURIComponent(currentFilename)}/write`,
            {
                method: "POST",
                body: JSON.stringify({
                    content: content,
                    expected_version: currentVersion,
                }),
            }
        );

        currentVersion = data.version;

        document.getElementById("version").textContent =
            `Version ${data.version}`;

        alert("File saved successfully!");

        await refreshDashboard();
    } catch (error) {
        alert(
            "Save failed:\n" +
            error.message +
            "\n\nThe file may have been modified by another process. " +
            "Reload it and try again."
        );

        await refreshDashboard();
    }
}

function showCreateDialog() {
    document.getElementById("modal").classList.remove("hidden");
}

function closeDialog() {
    document.getElementById("modal").classList.add("hidden");
}

async function createFile() {
    const filename =
        document.getElementById("newFilename").value.trim();

    const content =
        document.getElementById("newContent").value;

    if (!filename) {
        alert("Enter a filename.");
        return;
    }

    try {
        await api("/api/files", {
            method: "POST",
            body: JSON.stringify({
                filename: filename,
                content: content,
            }),
        });

        closeDialog();

        document.getElementById("newFilename").value = "";
        document.getElementById("newContent").value = "";

        await refreshDashboard();
    } catch (error) {
        alert("Could not create file:\n" + error.message);
    }
}

async function deleteFile(filename) {
    if (!confirm(`Delete ${filename}?`)) {
        return;
    }

    try {
        await api(
            `/api/files/${encodeURIComponent(filename)}`,
            { method: "DELETE" }
        );

        if (currentFilename === filename) {
            currentFilename = null;
            currentVersion = null;

            document.getElementById("currentFile").textContent =
                "No file selected";

            document.getElementById("version").textContent =
                "Version -";

            document.getElementById("editor").value = "";
            document.getElementById("editor").disabled = true;
        }

        await refreshDashboard();
    } catch (error) {
        alert("Delete failed:\n" + error.message);
    }
}

async function loadStatistics() {
    try {
        const data = await api("/api/statistics");

        document.getElementById("totalFiles").textContent =
            data.total_files;

        document.getElementById("operations").textContent =
            data.total_operations;

        document.getElementById("conflicts").textContent =
            data.conflicts_blocked;

        document.getElementById("writes").textContent =
            data.successful_writes;
    } catch (error) {
        console.error(error);
    }
}

async function loadLogs() {
    try {
        const logs = await api("/api/logs");
        const tbody = document.getElementById("logs");

        tbody.innerHTML = logs.map(log => {
            let statusClass = "";

            if (log.status === "SUCCESS") {
                statusClass = "success-status";
            } else if (log.status === "CONFLICT") {
                statusClass = "conflict-status";
            } else if (log.status === "BLOCKED") {
                statusClass = "blocked-status";
            }

            return `
                <tr>
                    <td>${escapeHtml(log.timestamp)}</td>
                    <td>PID ${escapeHtml(log.process_id)}</td>
                    <td>${escapeHtml(log.filename || "-")}</td>
                    <td>${escapeHtml(log.operation)}</td>
                    <td class="${statusClass}">
                        ${escapeHtml(log.status)}
                    </td>
                    <td>${escapeHtml(log.message)}</td>
                </tr>
            `;
        }).join("");
    } catch (error) {
        console.error(error);
    }
}

async function refreshDashboard() {
    await Promise.all([
        loadFiles(),
        loadStatistics(),
        loadLogs(),
    ]);
}

function escapeHtml(text) {
    return String(text)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

refreshDashboard();
setInterval(refreshDashboard, 2000);
